from flask import Flask,request,g

app = Flask(__name__)


@app.route('/')
def index():
    print('视图执行了')

    # g.name = '老王'
    # index2()
    name = request.args.get('name')
    return 'index'


@app.route('/getorder')
def getorders():
    uid = g.uid
    return 'getorder'

# def index2(name):
#     print(name)

def index2():
    name = g.name
    print(name)



@app.before_first_request
def before_first_request():
    print('第一次请求')
    '''初始化'''


@app.before_request
def before_request():
    print('每次请求前执行')
    # 用户是否登录

    g.uid = '321312312'
    '''
    权限校验
    '''


@app.after_request
def after_request(response):
    print('请求后执行，视图没有异常')
    # response.headers['name'] = 'laowang'
    #做返回统一处理
    return response


@app.teardown_request
def teardown_request(response):
    '''
    在debug非调试模式下
    :param response:
    :return:
    '''
    print('请求后执行，视图不管有没有出错都执行')
    return response


if __name__ == '__main__':
    app.run(debug=False)
