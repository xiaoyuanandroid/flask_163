from flask import Blueprint


page_cart = Blueprint('page_cart',__name__)

@page_cart.route('/getcart')
def getcart():
    return 'cart'
