from flask import Flask, session, render_template, request, redirect, url_for

import redis
from flask_session import Session

# 初始化flask_session对象
f_session = Session()

app = Flask(__name__)

# 配置
app.config['SECRET_KEY'] = 'laowangaigebi'  # 加密的密钥
app.config['SESSION_USE_SIGNER'] = True  # 是否对发送到浏览器上session的cookie值进行加密
app.config['SESSION_TYPE'] = 'redis'  # session类型为redis
app.config['SESSION_KEY_PREFIX'] = 'session:'  # 保存到session中的值的前缀
app.config['PERMANENT_SESSION_LIFETIME'] = 7200  # 失效时间 秒
app.config['SESSION_REDIS'] = redis.Redis(host='127.0.0.1', port='6379', db=4)  # redis数据库连接

# 绑定app对象
f_session.init_app(app)


@app.route('/')
def index():
    token = session.get('token')
    if token:
        username = session.get('username')
        return render_template('index1.html', username=username, token=token)
    else:
        return render_template('index1.html')


@app.route('/login', methods=['POST', 'GET'])
def login():
    if request.method == 'GET':
        return render_template('login100.html')
    else:

        if "username" not in request.form and "password" not in request.form:
            return redirect(url_for('login'))

        username = request.form.get('username')
        password = request.form.get('password')

        if not username or not password:
            return redirect(url_for('login'))


        if username == '123456' and password == '123456':
            # 会查到一个token
            session['token'] = "123456"
            session['username'] = username
            return redirect(url_for('index'))
        else:
            return redirect(url_for('login'))



@app.route('/logout')
def logout():
    session.clear()
    return redirect(url_for('index'))


if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=True)
