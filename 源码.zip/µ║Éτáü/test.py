from flask import Flask, render_template, request
from flask_wtf import FlaskForm
from wtforms import StringField, PasswordField, SubmitField
from wtforms.validators import DataRequired, EqualTo, Length

app = Flask(__name__)

app.config['SECRET_KEY'] = 'python is good'


class RegisterForm(FlaskForm):
    name = StringField(label='用户名', validators=[DataRequired('用户名不能为空')], render_kw={"class": "name"})
    password = PasswordField(label='密码', validators=[DataRequired('密码不能为空'), EqualTo('password1', '两次输入不一样'),
                                                     Length(min=6, max=8, message='至少6位，最大8位')])
    password1 = PasswordField(label='重复密码', validators=[DataRequired('密码不能为空'), Length(min=6, max=8)])
    submit = SubmitField('注册')


@app.route("/", methods=['POST', 'GET'])
def index():
    register_form = RegisterForm()
    if request.method == 'POST':
        if register_form.validate_on_submit():
            name = register_form.name.data
            password = register_form.password.data
            print(name, password)
            return '注册成功'

    return render_template('index10.html', register_form=register_form)


if __name__ == '__main__':
    app.run()
