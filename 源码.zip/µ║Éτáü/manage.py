from flask import Flask
# from cart import getcart
# from order import getorder

# 导入蓝图

from cart import page_cart
from order import page_order

app = Flask(__name__)

# app.route('/getorder')(getorder)
# app.route('/getcart')(getcart)


# 注册蓝图
app.register_blueprint(page_cart)
app.register_blueprint(page_order)


@app.route('/')
def index():
    return 'index'


''''
def a(name):
    def b(fun):
        def c()
            fun()
            
      return c
      
    return b         
        

'''

'''
django 把模块分成的小的app
'''

if __name__ == '__main__':
    # print(app.url_map)
    # from order import *
    # from cart import *
    app.run()
