from flask import Flask, render_template, make_response
from datetime import datetime

app = Flask(__name__)


@app.route("/")
def index():
    ctx = {
        'name': "laowang",
        'age': 12,
        'hobby': ["抽烟", "喝酒", "烫头"],
        'gender': {"man": "男", "woman": "女"},
        'desc': "<h1>我是隔壁老王</h1>",
        'nums': [1, 2],
        'time': datetime.now()
    }
    return render_template('index.html', **ctx)


def handletime(time, s):
    return time.strftime(s)


def add(num, num1):
    return num + num1


# 注册过滤器
app.jinja_env.filters['handletime'] = handletime
app.jinja_env.filters['add'] = add

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=True)
