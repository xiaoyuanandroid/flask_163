from flask import Flask, render_template, request, redirect, url_for, session
from flask_sqlalchemy import SQLAlchemy
from flask_session import Session
from datetime import datetime
import pymysql
import redis

pymysql.install_as_MySQLdb()

app = Flask(__name__)

app.config['SQLALCHEMY_DATABASE_URI'] = 'mysql://root:123456@127.0.0.1:3306/db_1807_flask'

# 数据库和模型类同步修改
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = True

# 查询时会显示原始SQL语句
app.config['SQLALCHEMY_ECHO'] = True

# 初始化flask_session对象
f_session = Session()

# 配置
app.config['SECRET_KEY'] = 'laowangaigebi'  # 加密的密钥
app.config['SESSION_USE_SIGNER'] = True  # 是否对发送到浏览器上session的cookie值进行加密
app.config['SESSION_TYPE'] = 'redis'  # session类型为redis
app.config['SESSION_KEY_PREFIX'] = 'session:'  # 保存到session中的值的前缀
app.config['PERMANENT_SESSION_LIFETIME'] = 7200  # 失效时间 秒
app.config['SESSION_REDIS'] = redis.Redis(host='127.0.0.1', port='6379', db=4)  # redis数据库连接

# 绑定app对象
f_session.init_app(app)

db = SQLAlchemy(app)


class UserInfo(db.Model):
    __tablename__ = 'tbl_userinfo'
    id = db.Column(db.Integer, primary_key=True)
    phone = db.Column(db.String(11), nullable=False, unique=True)
    password = db.Column(db.String(128), nullable=False)
    nickname = db.Column(db.String(64), nullable=False, default='')
    gender = db.Column(db.SmallInteger, nullable=False, default=1)
    create_time = db.Column(db.DATETIME, default=datetime.now())
    update_time = db.Column(db.DATETIME, default=datetime.now(), onupdate=datetime.now())

    @property
    def dec_gender(self):
        if self.gender == 0:
            return '女'
        else:
            return '男'


@app.route('/')
def index():
    uid = session.get('uid')

    if not uid:
        return render_template('index3.html')

    user = UserInfo.query.get(uid)

    if not user:
        return render_template('index3.html')

    user_list = UserInfo.query.filter(UserInfo.gender != user.gender).all()


    ctx = {
        'nickname': user.nickname,
        'user_list': user_list
    }
    return render_template('index3.html', **ctx)


@app.route('/login', methods=['POST', 'GET'])
def login():
    if request.method == 'GET':
        return render_template('login1.html')

    if 'phone' not in request.form or \
            'password' not in request.form:
        return redirect(url_for('login'))

    phone = request.form.get('phone')
    password = request.form.get('password')

    if not phone or not password:
        return redirect(url_for('login'))

    if not re_phone(phone):
        print('手机不合法')
        return redirect(url_for('login'))

    s_password = s_pwd(password)

    user = UserInfo.query.filter_by(phone=phone).first()

    if not user:
        print('账号没注册')
        return redirect(url_for('login'))

    if user.password != s_password:
        print('密码有错')
        return redirect(url_for('login'))

    session['uid'] = user.id

    session['nickname'] = user.nickname

    return redirect(url_for('index'))


@app.route('/logout')
def logout():
    session.clear()
    return redirect(url_for('index'))


'''
1、字段在不在form
2、取出来的为不为空
3、手机号是否合法  11
4、两次密码是否一样
5、密码位数是否正确 6-16
6、昵称是否争取  6-16
7、手机是否已经注册
8、性别是否合法  


测试来搞

'''

import hashlib


def s_pwd(password):
    return hashlib.md5(password.encode(encoding='UTF-8')).hexdigest()


import re


def re_phone(phone):
    return re.match(r'1[345678]\d{9}', phone)


@app.route('/register', methods=['POST', 'GET'])
def register():
    if request.method == 'GET':
        return render_template('register.html')

    if 'phone' not in request.form or \
            'password' not in request.form or \
            'password1' not in request.form or \
            'nickname' not in request.form or \
            'gender' not in request.form:
        return redirect(url_for('register'))

    phone = request.form.get('phone')
    password = request.form.get('password')
    password1 = request.form.get('password1')
    nickname = request.form.get('nickname')
    gender = request.form.get('gender')

    if not phone or not password or not password1 or not nickname or not gender:
        return redirect(url_for('register'))

    if not re_phone(phone):
        print('手机不合法')
        return redirect(url_for('register'))

    if password != password1:
        print('两次密码不一样')
        return redirect(url_for('register'))

    if gender not in ["0", "1"]:
        print('性别不合法')
        return redirect(url_for('register'))

    if len(password) < 6 or len(password) > 16:
        print('两次密码长度不对')
        return redirect(url_for('register'))

    if len(nickname) < 6 or len(nickname) > 16:
        print('昵称长度不对')
        return redirect(url_for('register'))

    # 查询手机号是否注册

    user = UserInfo.query.filter_by(phone=phone).first()

    if user:
        print('用户已存在')
        return redirect(url_for('register'))

    s_password = s_pwd(password)

    user = UserInfo()
    user.phone = phone
    user.password = s_password
    user.nickname = nickname
    user.gender = gender

    db.session.add(user)
    db.session.commit()

    return redirect(url_for('login'))


if __name__ == '__main__':
    app.run(debug=True)
    # db.create_all()
