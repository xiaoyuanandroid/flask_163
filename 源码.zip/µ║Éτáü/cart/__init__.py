from flask import Blueprint
page_cart = Blueprint('page_cart',__name__)

from .views import getcart