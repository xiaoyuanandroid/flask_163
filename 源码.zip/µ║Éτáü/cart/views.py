from . import page_cart




@page_cart.route('/getcart')
def getcart():
    return 'cart'
