from datetime import datetime
import operator
from flask import Flask, render_template, abort, request

from flask_sqlalchemy import SQLAlchemy

from flask_migrate import Migrate, MigrateCommand

from flask_script import Manager

import pymysql

pymysql.install_as_MySQLdb()

app = Flask(__name__)

# 设置连接数据库的URL
app.config['SQLALCHEMY_DATABASE_URI'] = 'mysql://root:123456@127.0.0.1:3306/db_1807_1_flask'

# 数据库和模型类同步修改
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = True

app.config['SQLALCHEMY_ECHO'] = True

manager = Manager(app)

db = SQLAlchemy(app)

# 管理
Migrate(app, db)

# 添加命令
manager.add_command('db', MigrateCommand)


class BaseModel(object):
    id = db.Column(db.Integer, primary_key=True)
    isdelete = db.Column(db.BOOLEAN, default=False)
    create_time = db.Column(db.DATETIME, default=datetime.now())
    update_time = db.Column(db.DATETIME, default=datetime.now(), onupdate=datetime.now())


# 辅助表
tbl_tags = db.Table('tbl_tags',
                    db.Column('tag_id', db.Integer, db.ForeignKey('tbl_tag.id')),
                    db.Column('article_id', db.Integer, db.ForeignKey('tbl_article.id')))


# 文章表
class Article(BaseModel, db.Model):
    __tablename__ = 'tbl_article'
    title = db.Column(db.String(32), default='')
    content = db.Column(db.TEXT, default='')
    category_id = db.Column(db.Integer, db.ForeignKey('tbl_catgegory.id'))

    tags = db.relationship('Tag', secondary=tbl_tags, backref='articles')

    def __repr__(self):
        return self.title



# 分类表
class Category(BaseModel, db.Model):
    __tablename__ = 'tbl_catgegory'
    name = db.Column(db.String(32), default='')
    articles = db.relationship('Article', backref='category')

    def __repr__(self):
        return self.name




# 标签表
class Tag(BaseModel, db.Model):
    __tablename__ = 'tbl_tag'
    name = db.Column(db.String(32), default='')

    def __repr__(self):
        return self.name


# http://127.0.0.1:5000/?category=1
# http://127.0.0.1:5000/?tag=1
# http://127.0.0.1:5000

@app.route('/')
def index():
    if 'category' not in request.args and 'tag' not in request.args:
        articles = Article.query.filter_by(isdelete=False).order_by(Article.create_time.desc()).all()
        return render_template('index5.html', articles=articles)

    if 'category' in request.args:
        category_id = request.args.get('category')

        category = Category.query.get(category_id)

        if not category:
            abort(404)

        articles = Article.query.filter_by(category_id=category_id, isdelete=False).order_by(
            Article.create_time.desc()).all()
        return render_template('index5.html', articles=articles)

    if 'tag' in request.args:
        tag_id = request.args.get('tag')

        tag = Tag.query.get(tag_id)

        if not tag:
            abort(404)
        articles = tag.articles  # 这个快会不会把删除的文章显示出来，

        l_articles = []
        for article in articles:
            if not article.isdelete:
                l_articles.append(article)
        l_articles.sort(key=lambda x: x.create_time, reverse=True)
        return render_template('index5.html', articles=l_articles)


@app.route('/article/<id>')
def article(id):
    article = Article.query.get(id)
    if not article:
        abort(404)
    return render_template('article.html', article=article)


if __name__ == '__main__':
    manager.run()
    #
    # db.drop_all()
    # db.create_all()
    #
    # category1 = Category(name='程序人生')
    # category2 = Category(name='技术杂谈')
    #
    # db.session.add_all([category1, category2])
    #
    #
    #
    # tag1 = Tag(name='程序员')
    # tag2 = Tag(name='生活')
    # tag3 = Tag(name='Python')
    #
    # db.session.add_all([tag1, tag2, tag3])
    #
    # article = Article()
    # article.title = '不想当程序员了'
    # article.content = '学不动了学不动了学不动了学不动了学不动了学不动了学不动了'
    # article.category = category1
    # article.tags.append(tag1)
    # article.tags.append(tag2)
    #
    # article1 = Article()
    # article1.title = 'Python入门'
    # article1.content = 'print(Hello)'
    # article1.category = category2
    # article1.tags.append(tag3)
    #
    # db.session.add_all([article, article1])
    #
    # db.session.commit()
