from flask import Flask, request, render_template, current_app, redirect, url_for, flash

from werkzeug.utils import secure_filename
from flask import send_from_directory
import os

app = Flask(__name__)

app.config.from_pyfile('config.cfg')
app.config['SECRET_KEY'] = 'dakhjshdjkashjkdhasjk'

@app.route("/")
def index():
    # return render_template('get.html')
    return render_template('post.html')


@app.route('/get')
def get():
    name = request.args.get("name")
    age = request.args.get('age')

    # print(request.values.get('name'))
    return name + age


@app.route('/post', methods=['POST', 'GET'])
def post():
    name = request.form.get('name')
    age = request.form.get('age')
    hobbys = request.form.getlist('hobby')  # 一键多值

    # print(request.values.getlist('hobby'))

    print(request.url)
    print(request.content_type)
    print(request.path)
    print(request.method)
    print(request.content_length)
    print(request.content_md5)
    print(request.content_encoding)
    print(request.cookies)
    return name + age + str(hobbys)


# xxxx.jpg

# ["xxx", "jpg"]

# xxx.xxx.jpg  xxx.JPG

# ["xxx.xxx", "jpg"]


def allow(filename):
    return "." in filename and filename.rsplit(".", 1)[1].lower() in app.config.get('ALLOW_FILES')


@app.route("/upload", methods=['POST', 'GET'])
def upload():
    if request.method == 'GET':
        return render_template('upload.html')
    else:

        # 判断
        if 'file' not in request.files:
            return redirect(request.url)

        file = request.files.get('file')

        if file.filename == '':
            return redirect(request.url)

        if file and allow(file.filename):
            # 永远不相信用户的输入
            # '../../../config.jpg'
            # print(secure_filename('../../../config.cfg'))

            filename = secure_filename(file.filename)  # 检验文件的名字
            file.save(os.path.join(app.config.get('UPLOAD_DIR'), filename))
            flash('上传成功','success')
            flash('上传成功')
            # return redirect(url_for('show', filename=filename))
            return redirect(url_for('upload'))


# 展示图片
@app.route('/show/<filename>')
def show(filename):
    return send_from_directory(app.config.get('UPLOAD_DIR'), filename)


if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=True)
