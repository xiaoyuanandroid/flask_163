from flask import Flask, abort, Response, request
from flask_sqlalchemy import SQLAlchemy

app = Flask(__name__)




@app.route("/")
def index():
    name = request.args.get('name')

    if name != 'laowang':
        abort(502)
    print('哈哈哈')
    return "index"


@app.errorhandler(502)
def handle_error(error):
    return '服务器泡妞去了'


if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=True)
