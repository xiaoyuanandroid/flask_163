from flask import Flask, render_template, make_response, request
from datetime import datetime


app = Flask(__name__)


@app.route("/")
def index():
    response = make_response(render_template('post.html'))

    response.set_cookie('name', 'laowang', max_age=10)
    response.set_cookie('age', "12", expires=datetime(2019, 4, 24))

    # 删除cookie
    response.delete_cookie('name')

    response.headers['auth'] = '132123123'


    return response


@app.route('/center')
def center():
    cookies = request.cookies
    print(cookies)
    return str(cookies)


if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=True)
