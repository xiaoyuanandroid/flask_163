from flask import Flask, redirect, url_for

app = Flask(__name__, )


@app.route('/')
def index():
    return 'hello world'


# @app.route('/mycenter')
@app.route('/center')
def center():
    return 'my center'


@app.route('/mycenter')
def mycenter():
    return redirect(url_for('center'))


@app.route('/getorder', methods=['POST', 'GET'])
def getOrder():
    return "my order"


if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=True)
