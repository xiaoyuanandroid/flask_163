from flask import Flask,current_app

# 创建flask应用
# __name__ 指的是当前文件为主目录 默认以这个目录为主目录

# static_url_path 隐藏真是静态路径
# abc不能写
app = Flask(__name__,
            static_url_path="/1807",
            static_folder='static',
            template_folder='templates')


@app.route('/')
def index():
    # print(1/0)
    # 读取参数
    # arg = app.config.get('TEST')
    arg = current_app.config.get('TEST')
    print(arg)
    return 'hello world'


# def test(a):
#     def inner(a):
#         def haha():
#             a()
#
#         return haha
#     return inner

# 从文件找
app.config.from_pyfile('config.cfg')

# 从类中找
# class Config():
#     DEBUG = True
#
# app.config.from_object(Config)

# 直接操作
# app.config['DEBUG'] = True

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000)
