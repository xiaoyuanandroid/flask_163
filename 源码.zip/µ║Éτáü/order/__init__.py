from flask import Blueprint

page_order = Blueprint('page_order', __name__, template_folder='templates')

from .views import getorder
