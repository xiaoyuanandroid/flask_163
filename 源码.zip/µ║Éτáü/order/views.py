from . import page_order
from flask import render_template


@page_order.route('/getorder')
def getorder():
    return render_template('order.html')
