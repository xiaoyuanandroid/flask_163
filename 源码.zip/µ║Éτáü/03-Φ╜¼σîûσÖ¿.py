from flask import Flask, redirect, url_for
from werkzeug.routing import BaseConverter, IntegerConverter, FloatConverter
from werkzeug.utils import secure_filename

app = Flask(__name__, )


# 自定义转化器
class MyConverter(BaseConverter):

    def __init__(self, map, re):
        super().__init__(map)  # 调用父类 父类会咱们初始化一些东西
        self.regex = re

    def to_python(self, value):
        return value

    def to_url(self, value):
        return value


# 注册转化器
app.url_map.converters['re'] = MyConverter


@app.route("/mycenter/<re(r'\d{11}'):uid>")
def mycenter(uid):
    print(type(uid))
    return str(uid)


@app.route("/register/<re(r'1[3456789]\d{9}'):phone>")
def register(phone):
    return redirect(url_for("mycenter", uid=phone), )


if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=True)
