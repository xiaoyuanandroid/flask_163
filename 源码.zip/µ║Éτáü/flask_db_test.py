from flask import Flask, render_template
from flask_sqlalchemy import SQLAlchemy
import pymysql

pymysql.install_as_MySQLdb()

app = Flask(__name__)

app.config['SQLALCHEMY_DATABASE_URI'] = 'mysql://root:123456@127.0.0.1:3306/db_1807_flask'

# 数据库和模型类同步修改
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = True

# 查询时会显示原始SQL语句
app.config['SQLALCHEMY_ECHO'] = True

# 绑定app

db = SQLAlchemy(app)


class Type(db.Model):  # 射手 、法师
    __tablename__ = 'tbl_types'  # 表名

    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(16), unique=True, default='')

    # 方便查找 这个字段不存在数据库当中
    heros = db.relationship('Hero', backref='type')

    def __repr__(self):
        return self.name


class Hero(db.Model):  # 后裔
    __tablename__ = 'tbl_heros'

    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(32), unique=True)

    # 外键
    type_id = db.Column(db.Integer, db.ForeignKey('tbl_types.id'))

    is_delete = db.Column(db.BOOLEAN,default=False)
    def __repr__(self):
        return self.name


@app.route('/')
def index():
    types = Type.query.all()

    ctx = {
        'types': types
    }



    return render_template('index2.html', **ctx)


@app.route('/hero/<int:id>')
def hero(id):
    type = Type.query.get(id)

    heros = type.heros
    ctx = {
        'heros': heros
    }
    return render_template('hero.html', **ctx)


if __name__ == '__main__':
    # app.run(host='0.0.0.0', port=5000, debug=True)


    # 更新操作
    # hero = Hero.query.get(1)
    # hero.name = '鲁班'
    #
    # db.session.add(hero)
    # db.session.commit()

    hero = Hero.query.get(1)
    db.session.delete(hero)
    # db.session.commit()





    # db.drop_all()  # *************** 慎重使用
    # db.create_all()  # 创建表
    #
    # type = Type(name='射手')
    # db.session.add(type)  # 把数据添加到会话里面
    # db.session.commit()

    #
    # type1 = Type(name='坦克')
    # type2 = Type(name='法师')
    # db.session.add_all([type1,type2])
    # db.session.commit()
    #
    # hero = Hero(name='后裔', type_id=1)
    # hero2 = Hero(name='孙尚香', type_id=1)
    # db.session.add(hero)
    # db.session.add(hero2)
    # db.session.commit()

