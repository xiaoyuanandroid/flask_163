from flask import Blueprint

page_order = Blueprint('page_order', __name__)


@page_order.route('/getorder')
def getorder():
    return 'order'
