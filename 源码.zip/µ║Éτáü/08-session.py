from flask import Flask, session

import redis
from flask_session import Session



#初始化flask_session对象
f_session = Session()

app = Flask(__name__)


#配置
app.config['SECRET_KEY'] = 'laowangaigebi'  # 加密的密钥
app.config['SESSION_USE_SIGNER'] = True  # 是否对发送到浏览器上session的cookie值进行加密
app.config['SESSION_TYPE'] = 'redis'  # session类型为redis
app.config['SESSION_KEY_PREFIX'] = 'session:'  # 保存到session中的值的前缀
app.config['PERMANENT_SESSION_LIFETIME'] = 7200  # 失效时间 秒
app.config['SESSION_REDIS'] = redis.Redis(host='127.0.0.1', port='6379', db=4)  # redis数据库连接


# 绑定app对象
f_session.init_app(app)




@app.route("/")
def index():
    session['uid'] = "101102"
    session['nickname'] = "laowang"
    return "存session"


@app.route("/center")
def center():
    uid = session.get('uid')
    nickname = session.get('nickname')

    return uid + nickname


if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=True)
