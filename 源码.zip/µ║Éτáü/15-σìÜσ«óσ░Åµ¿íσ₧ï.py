from flask import Flask, render_template, abort, request
from flask_script import Manager
from flask_sqlalchemy import SQLAlchemy
from flask_migrate import Migrate, MigrateCommand
from datetime import datetime
import pymysql

pymysql.install_as_MySQLdb()

app = Flask(__name__)

# 设置连接数据库的URL
app.config['SQLALCHEMY_DATABASE_URI'] = 'mysql://root:123456@127.0.0.1:3306/db_1807_1_flask'

# 数据库和模型类同步修改
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = True

app.config['SQLALCHEMY_ECHO'] = True

# 创建管理对象
manager = Manager(app)

db = SQLAlchemy(app)

# 管理
Migrate(app, db)

# 添加命令
manager.add_command('db', MigrateCommand)


class BaseMode(object):
    isdelete = db.Column(db.BOOLEAN, default=False)
    create_time = db.Column(db.DATETIME, default=datetime.now())
    update_time = db.Column(db.DATETIME, default=datetime.now(), onupdate=datetime.now())


tbl_tags = db.Table('db_tbl_tags',
                    db.Column('tag_id', db.Integer, db.ForeignKey('tbl_tag.id')),
                    db.Column('article_id', db.Integer, db.ForeignKey('tbl_article.id'))
                    )


class Article(BaseMode, db.Model):
    __tablename__ = 'tbl_article'
    id = db.Column(db.Integer, primary_key=True)
    title = db.Column(db.String(128))
    content = db.Column(db.TEXT, default='')
    category_id = db.Column(db.ForeignKey('tbl_category.id'))
    tags = db.relationship('Tag', secondary=tbl_tags, backref='articles')


class Tag(BaseMode, db.Model):
    __tablename__ = 'tbl_tag'
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(10))


class Category(BaseMode, db.Model):
    __tablename__ = 'tbl_category'
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(10))
    articles = db.relationship('Article', backref='category')


@app.route('/')
def index():
    if 'category' not in request.args and 'tag' not in request.args:
        articles = Article.query.filter_by(isdelete=False).order_by(Article.id.desc()).all()
        return render_template('index4.html', articles=articles)

    if 'category' in request.args:
        category_id = request.args.get('category')
        category = Category.query.get(category_id)
        if not category:
            abort(404)

        articles = category.articles
        return render_template('index4.html', articles=articles)

    if 'tag' in request.args:
        tag_id = request.args.get('tag')
        tag = Tag.query.get(tag_id)
        if not tag:
            abort(
                404)
        articles = tag.articles
        return render_template('index4.html', articles=articles)




@app.route('/article/<int:id>')
def detail(id):
    print('dddddddddddddddddddddddddddddd')
    article = Article.query.get(id)
    if not article:
        abort(404)

    return render_template('detail.html', article=article)


if __name__ == '__main__':
    manager.run()
    # db.drop_all()
    # db.create_all()
    # tag1 = Tag(name='语言')
    # tag2 = Tag(name='计算机')
    #
    # db.session.add_all([tag1, tag2])
    #
    # category = Category(name='Python')
    #
    # db.session.add(category)
    #
    # article = Article()
    # article.title = 'Python语言已经第一了'
    # article.content = '在2019年Python语言已经第一了 哈哈哈真好在2019年Python语言已经第一了 哈哈哈真好在2019年Python语言已经第一了 哈哈哈真好'
    # article.tags.append(tag1)
    # article.tags.append(tag2)
    # article.category = category
    # db.session.add(article)
    #
    # article1 = Article()
    # article1.title = 'Python真火啊'
    # article1.content = '不错不错不错不错不错不错不错不错不错不错不错不错不错不错不错不错不错'
    # article1.tags.append(tag1)
    # article1.tags.append(tag2)
    # article1.category = category
    # db.session.add(article1)
    #
    #
    # db.session.commit()
