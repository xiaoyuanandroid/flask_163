from datetime import datetime
import operator
from flask import Flask, render_template, abort, request, redirect, url_for

from flask_sqlalchemy import SQLAlchemy

from flask_migrate import Migrate, MigrateCommand

from flask_script import Manager

import pymysql

pymysql.install_as_MySQLdb()

app = Flask(__name__)

# 设置连接数据库的URL
app.config['SQLALCHEMY_DATABASE_URI'] = 'mysql://root:123456@127.0.0.1:3306/db_1807_2_flask'

# 数据库和模型类同步修改
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = True

app.config['SQLALCHEMY_ECHO'] = True

manager = Manager(app)

db = SQLAlchemy(app)

# 管理
Migrate(app, db)

# 添加命令
manager.add_command('db', MigrateCommand)


class BaseModel(object):
    id = db.Column(db.Integer, primary_key=True)
    isdelete = db.Column(db.BOOLEAN, default=False)
    create_time = db.Column(db.DATETIME, default=datetime.now())
    update_time = db.Column(db.DATETIME, default=datetime.now(), onupdate=datetime.now())


# 学生表
class Student(BaseModel, db.Model):
    __tablename__ = 'tbl_student'
    name = db.Column(db.String(32), default='')
    age = db.Column(db.Integer, default=1, nullable=False)
    gender = db.Column(db.SmallInteger, default=1, nullable=False)


    def __repr__(self):
        return self.title


# 科目表
class Subject(BaseModel, db.Model):
    __tablename__ = 'tbl_subject'
    name = db.Column(db.String(32), default='')

    def __repr__(self):
        return self.name

# 成绩---->学生
# 学生---->成绩s


#成绩------> 科目
#科目------> 成绩s

# 成绩表
class Grade(BaseModel, db.Model):
    __tablename__ = 'tbl_grade'
    student_id = db.Column(db.Integer, db.ForeignKey('tbl_student.id'))
    subject_id = db.Column(db.Integer, db.ForeignKey('tbl_subject.id'))
    grade = db.Column(db.FLOAT, default=0)

    student = db.relationship('Student', backref='grades')



    subject = db.relationship('Subject', backref='grades')

    def __repr__(self):
        return self.name


@app.route('/')
def index():
    grades = Grade.query.all()
    return render_template('index6.html', grades=grades)


@app.route('/add', methods=['POST', 'GET'])
def add():
    if request.method == 'GET':
        return render_template('add.html')
    if 'name' not in request.form or \
            'gender' not in request.form or \
            'age' not in request.form or \
            'subject' not in request.form or \
            'grade' not in request.form or \
            'code' not in request.form:
        return redirect(url_for('index'))

    name = request.form.get('name')
    gender = request.form.get('gender')
    age = request.form.get('age')
    grade = request.form.get('grade')
    subject = request.form.get('subject')
    code = request.form.get('code')

    if not name or not gender or not age or not grade or not subject:
        return redirect(url_for('index'))

    if len(name) < 1 or len(name) > 10:
        print('名字错误')
        return redirect(url_for('index'))

    if gender not in ['0', '1']:
        print('性别不合法')
        return redirect(url_for('index'))

    if int(age) <= 0 or int(age) > 120:
        print('年龄不合法')
        return redirect(url_for('index'))

    if float(grade) < 0 or float(grade) > 120:
        print('成绩不合法')
        return redirect(url_for('index'))




    # 根据学号查学生
    stu = Student.query.get(code)

    if stu:  # 如果学生库中以存在
        sub = Subject.query.filter_by(name=subject).first()  #语文
        if sub:  # 如果科目库中以存在
            gra = Grade.query.filter_by(student_id=code).first()
            if gra:  # 如果成绩库中以存在
                print('成绩已录入')
                return redirect(url_for('index'))
            else:  # 如果成绩不存在 则录入成绩  科目和学生不在添加数据库
                gra = Grade()
                gra.student_id = stu.id
                gra.subject_id = sub.id
                gra.grade = grade
                db.session.add(gra)
                db.session.commit()
        else:  # 如果科目不存在 则录入科目和成绩，学生不在添加数据库

            sub = Subject()
            sub.name = subject
            db.session.add(sub)
            db.session.commit()

            gra = Grade()
            gra.student_id = stu.id
            gra.subject_id = sub.id
            gra.grade = grade
            db.session.add(gra)
            db.session.commit()

    else:  # 如果学生不存在
        sub = Subject.query.filter_by(name=subject).first()

        if sub:  # 如果科目存在 则录入学生和成绩 不录入科目
            stu = Student()
            stu.id = code
            stu.name = name
            stu.gender = gender
            stu.age = age
            db.session.add(stu)
            db.session.commit()

            gra = Grade()
            gra.student_id = stu.id
            gra.subject_id = sub.id
            gra.grade = grade
            db.session.add(gra)
            db.session.commit()
        else:  # 除非 录入学生、科目、成绩
            stu = Student()
            stu.id = code
            stu.name = name
            stu.gender = gender
            stu.age = age
            db.session.add(stu)
            db.session.commit()

            sub = Subject()
            sub.name = subject
            db.session.add(sub)
            db.session.commit()

            gra = Grade()
            gra.student_id = stu.id
            gra.subject_id = sub.id
            gra.grade = grade

            db.session.add(gra)
            db.session.commit()

    return redirect(url_for('index'))


if __name__ == '__main__':
    manager.run()
    #
    # db.drop_all()
    # db.create_all()
