from flask import Flask, make_response, jsonify

app = Flask(__name__)


@app.route("/")
def index():
    # return ("自定义响应", "404 notfound ", {"name": "laowang"})

    # response = make_response('dhuasj')
    # response.headers['name'] = 'laowang'
    # response.status = "404 notfound"
    # return response
    ctx = {
        "name": "laowang",
        "age": 12
    }
    return jsonify(ctx)


if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=True)
