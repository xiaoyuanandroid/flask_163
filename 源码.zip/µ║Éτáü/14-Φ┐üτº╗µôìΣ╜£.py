from flask import Flask
from flask_script import Manager
from flask_sqlalchemy import SQLAlchemy
from flask_migrate import Migrate, MigrateCommand

import pymysql

pymysql.install_as_MySQLdb()


app = Flask(__name__)

# 设置连接数据库的URL
app.config['SQLALCHEMY_DATABASE_URI'] = 'mysql://root:123456@127.0.0.1:3306/db_1807_1_flask'

# 数据库和模型类同步修改
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = True


app.config['SQLALCHEMY_ECHO'] = True

# 创建管理对象
manager = Manager(app)


db = SQLAlchemy(app)

# 管理
Migrate(app, db)

# 添加命令
manager.add_command('db', MigrateCommand)


class Student(db.Model):
    __tablename__ = 'tbl_student'
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(10))
    age = db.Column(db.String(10))


if __name__ == '__main__':
    manager.run()
